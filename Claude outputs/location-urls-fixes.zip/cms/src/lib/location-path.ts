/**
 * Builds the location part of a page URL. The CMS never knows the main site's
 * base path (`/seo-services`, `/video`, ...): it only returns
 *   nested country → "country/state/slug"
 *   flat country   → "country/slug"
 * and the main site prefixes its own base path.
 */

import { SLUG_PATTERN } from "@/lib/slugify";

export type CountryUrlType = "nested" | "flat";

export interface LocationRowFields {
  country_id?: number | null;
  country_name?: string | null;
  country_slug?: string | null;
  country_url_type?: string | null;
  state_id?: number | null;
  state_name?: string | null;
  state_slug?: string | null;
}

export interface PublicCountry {
  id: number;
  name: string;
  slug: string | null;
  url_type: CountryUrlType;
}

export interface PublicState {
  id: number;
  name: string;
  slug: string | null;
}

export interface LocationFields {
  location_path: string | null;
  country: PublicCountry | null;
  state: PublicState | null;
  country_slug: string | null;
  state_slug: string | null;
  url_type: CountryUrlType | null;
}

/**
 * SELECT columns + JOINs that every page query adds so location fields come
 * back in one round trip. `p` must be the page table alias. The state join
 * also checks the state belongs to the page's country, so inconsistent data
 * produces no path instead of a wrong one.
 */
export const LOCATION_COLUMNS = `
  c.name AS country_name, c.slug AS country_slug, c.url_type AS country_url_type,
  s.name AS state_name, s.slug AS state_slug`;

export const LOCATION_JOINS = `
  LEFT JOIN cms_countries c ON p.country_id = c.id
  LEFT JOIN cms_states s ON p.state_id = s.id AND s.country_id = p.country_id`;

export function normalizeUrlType(value: unknown): CountryUrlType {
  return value === "flat" ? "flat" : "nested";
}

export function buildLocationPath(
  slug: string,
  row: LocationRowFields
): string | null {
  // A legacy slug that isn't URL-safe ("Los Angeles SEO") gets no new URL:
  // the page keeps working on its old URL until the slug is renamed.
  if (!slug || !SLUG_PATTERN.test(slug) || !row.country_slug) return null;
  if (normalizeUrlType(row.country_url_type) === "flat") {
    return `${row.country_slug}/${slug}`;
  }
  if (!row.state_slug) return null;
  return `${row.country_slug}/${row.state_slug}/${slug}`;
}

export function toLocationFields(slug: string, row: LocationRowFields): LocationFields {
  const urlType = row.country_id ? normalizeUrlType(row.country_url_type) : null;
  const country: PublicCountry | null =
    row.country_id && row.country_name
      ? {
          id: row.country_id,
          name: row.country_name,
          slug: row.country_slug ?? null,
          url_type: normalizeUrlType(row.country_url_type),
        }
      : null;
  // A flat country has no state level in its URLs, so no state is exposed.
  const state: PublicState | null =
    urlType === "nested" && row.state_id && row.state_name
      ? { id: row.state_id, name: row.state_name, slug: row.state_slug ?? null }
      : null;

  return {
    location_path: buildLocationPath(slug, row),
    country,
    state,
    country_slug: country?.slug ?? null,
    state_slug: state?.slug ?? null,
    url_type: urlType,
  };
}
